// =================================================================================================
// CABTMIDILocalPeripheralViewController.h
// =================================================================================================
/*
 File:		CABTMIDILocalPeripheralViewController.h
 Framework:	CoreAudioKit
 
 Copyright (c) 2014 Apple Inc. All Rights Reserved.
 */

#import <UIKit/UIKit.h>

NS_CLASS_AVAILABLE_IOS(8_0)
@interface CABTMIDILocalPeripheralViewController : UIViewController
@end
