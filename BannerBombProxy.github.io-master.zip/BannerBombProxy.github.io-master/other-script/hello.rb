print "Hello, World!\n"
