#!/usr/bin/python
# Say hello, world.
print "Hello, world!"
