# SimsVIP.Servo
A Discord bot made for the SimsVIP server, using discord.py.
