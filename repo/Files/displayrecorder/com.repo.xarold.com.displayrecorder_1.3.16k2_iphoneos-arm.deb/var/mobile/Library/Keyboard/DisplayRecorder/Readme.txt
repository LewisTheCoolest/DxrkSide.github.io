Recordings will be saved in this directory.
