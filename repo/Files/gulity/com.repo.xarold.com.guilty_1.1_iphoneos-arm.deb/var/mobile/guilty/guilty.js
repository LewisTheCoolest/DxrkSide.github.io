#!/usr/bin/env node
var plist = require('plist');
var ios = require('ios');
var sys = require('util');
var exec = require('child_process').exec;
var args = process.argv.slice(2);
var acc = ['-novibrate','-nobanner','-console'];
var vibrate = banner = true, console = false;

var CRASHFILE = '/private/var/mobile/Library/Logs/CrashReporter/LatestCrash.plist';
var ANNOUNCE = 'Behold the crash\'s guilty:';

for (var i=0; i<args.length; i++)
{
	if (acc.indexOf(args[i]) >= 0)
	{
		if (args[i] == acc[0])
			vibrate = false;

		if (args[i] == acc[1])
			banner = false;
		
		if (args[i] == acc[2])
			console = true;
	}
	else
		argumentMismatch();
}

function argumentMismatch() {
sys.puts('\nAccepted arguments:\n\n\
Use: -novibrate		# to remove vibration when finding the crash\'s guilties\n\
Use: -nobanner		# to stop notification showing the guilties\n\
			  this option forces \'console\'\n\
Use: -console		# to show the guilties on the stdout (the active console)\n');
	process.exit();
}

function puts(error, stdout, stderr) {

	if (stdout != '')
	{
		var obj = plist.parseStringSync(stdout);
		var guilties = '';
		for (var key in obj.blame)
		{
			blame = obj.blame[key].toString();
			guilties += blame.substr(0,blame.indexOf(','))+'\n';
		}
		showResult(ANNOUNCE+'\n\n'+guilties);
	}
	else {
		showResult('There is no CrashReporter logs.\n\nCheck /var/mobile/Library/Logs/CrashReporter/ and see if there is LatestCrash.plist');
	}
}

function showResult (text) {
	if (banner == true)
		ios.createNotification({message:text,defaultButton: 'OK! I\'m gonna fix this',});
	if (console == true || banner == false)
		sys.puts(text);
	if (vibrate == true)
		ios.vibrate();
}

exec('symbolicate '+CRASHFILE, puts);

if (banner == true)
	exec('sleep 30s');