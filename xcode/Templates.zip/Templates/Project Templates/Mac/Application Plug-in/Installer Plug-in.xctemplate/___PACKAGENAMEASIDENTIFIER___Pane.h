//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <InstallerPlugins/InstallerPlugins.h>

@interface ___PACKAGENAMEASIDENTIFIER___Pane : InstallerPane

@end
