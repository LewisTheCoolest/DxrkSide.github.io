//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "___PACKAGENAMEASIDENTIFIER___PlugInLoader.h"

@implementation ___PACKAGENAMEASIDENTIFIER___PlugInLoader

- (BOOL)load:(void *)host
{
    // custom plug-in initialization code goes here
    return YES;
}

@end
