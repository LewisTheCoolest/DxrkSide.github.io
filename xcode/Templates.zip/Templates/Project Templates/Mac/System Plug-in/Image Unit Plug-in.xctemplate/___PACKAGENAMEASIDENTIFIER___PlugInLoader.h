//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <QuartzCore/CoreImage.h>

@interface ___PACKAGENAMEASIDENTIFIER___PlugInLoader : NSObject <CIPlugInRegistration>

- (BOOL)load:(void *)host;

@end
