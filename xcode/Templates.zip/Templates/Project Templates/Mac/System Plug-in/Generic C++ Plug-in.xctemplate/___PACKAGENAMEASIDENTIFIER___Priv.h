/*
 *  ___FILENAME___
 *  ___PACKAGENAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *___COPYRIGHT___
 *
 */

#include <CoreFoundation/CoreFoundation.h>

#pragma GCC visibility push(hidden)

class C___PACKAGENAMEASIDENTIFIER___ {
	public:
		CFStringRef UUID(void);
};

#pragma GCC visibility pop
