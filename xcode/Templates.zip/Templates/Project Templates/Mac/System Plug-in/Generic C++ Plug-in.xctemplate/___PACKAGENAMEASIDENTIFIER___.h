/*
 *  ___FILENAME___
 *  ___PACKAGENAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *___COPYRIGHT___
 *
 */

extern "C" {
#pragma GCC visibility push(default)

/* External interface to the ___PACKAGENAMEASIDENTIFIER___, C-based */

CFStringRef ___PACKAGENAMEASIDENTIFIER___UUID(void);

#pragma GCC visibility pop
}
