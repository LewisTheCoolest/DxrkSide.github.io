//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <PreferencePanes/PreferencePanes.h>

@interface ___PACKAGENAMEASIDENTIFIER___ : NSPreferencePane

- (void)mainViewDidLoad;

@end
