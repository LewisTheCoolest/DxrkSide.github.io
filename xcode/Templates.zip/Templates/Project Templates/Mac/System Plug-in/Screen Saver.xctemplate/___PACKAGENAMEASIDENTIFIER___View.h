//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <ScreenSaver/ScreenSaver.h>

@interface ___PACKAGENAMEASIDENTIFIER___View : ScreenSaverView

@end
