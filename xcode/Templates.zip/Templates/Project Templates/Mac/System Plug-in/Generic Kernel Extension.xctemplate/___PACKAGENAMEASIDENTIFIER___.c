//
//  ___FILENAME___
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#include <mach/mach_types.h>

kern_return_t ___PACKAGENAMEASIDENTIFIER____start(kmod_info_t * ki, void *d);
kern_return_t ___PACKAGENAMEASIDENTIFIER____stop(kmod_info_t *ki, void *d);

kern_return_t ___PACKAGENAMEASIDENTIFIER____start(kmod_info_t * ki, void *d)
{
    return KERN_SUCCESS;
}

kern_return_t ___PACKAGENAMEASIDENTIFIER____stop(kmod_info_t *ki, void *d)
{
    return KERN_SUCCESS;
}
