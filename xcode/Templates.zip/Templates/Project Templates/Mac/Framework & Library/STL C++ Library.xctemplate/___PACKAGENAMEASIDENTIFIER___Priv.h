/*
 *  ___FILENAME___
 *  ___PACKAGENAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *___COPYRIGHT___
 *
 */

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

class ___PACKAGENAMEASIDENTIFIER___Priv
{
	public:
		void HelloWorldPriv(const char *);
};

#pragma GCC visibility pop
