/*
 *  ___FILENAME___
 *  ___PACKAGENAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *___COPYRIGHT___
 *
 */

#ifndef ___PACKAGENAMEASIDENTIFIER____
#define ___PACKAGENAMEASIDENTIFIER____

/* The classes below are exported */
#pragma GCC visibility push(default)

class ___PACKAGENAMEASIDENTIFIER___
{
	public:
		void HelloWorld(const char *);
};

#pragma GCC visibility pop
#endif
