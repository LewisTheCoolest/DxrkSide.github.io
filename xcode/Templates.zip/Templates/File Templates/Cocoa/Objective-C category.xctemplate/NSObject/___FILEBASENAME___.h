//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

___IMPORTHEADER_categoryClass___

@interface ___VARIABLE_categoryClass:identifier___ (___VARIABLE_categoryName:identifier___)

@end
