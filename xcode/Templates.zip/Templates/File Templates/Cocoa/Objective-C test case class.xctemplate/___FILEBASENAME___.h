//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <SenTestingKit/SenTestingKit.h>

@interface ___FILEBASENAMEASIDENTIFIER___ : SenTestCase

@end
